global.cookies = false; 
